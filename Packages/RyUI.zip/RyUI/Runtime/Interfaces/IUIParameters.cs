﻿namespace Snowship.NUI {
	public interface IUIParameters {

	}
}
